# EditFlow AI

An original Android video-editor project designed for Android 8.0+.

## Open in VS Code

1. Extract the ZIP.
2. Open the `EditFlowAI` folder in VS Code.
3. Install the Android/Gradle/Kotlin extensions if desired.
4. Open the project in Android Studio for the easiest Gradle sync and emulator/device testing.
5. Use JDK 17.
6. Run the `app` configuration.

## Current foundation

- Kotlin
- Jetpack Compose
- Material 3
- Android 8.0+ minimum SDK
- Media3 dependencies
- Room dependencies
- Navigation-ready architecture
- Dark editor UI
- Home/project screen
- Editor screen
- Timeline foundation
- Editing toolbar foundation

## Important

This ZIP is a clean starter implementation, not a claim that all advanced video-processing requirements in the supplied specification have already been implemented. A production editor requires implementing and testing the media renderer/export pipeline, real timeline mutations, audio mixing, text compositing, effects, keyframes, project persistence, and device-specific performance handling.

The UI and branding are original and do not copy CapCut assets or proprietary UI.

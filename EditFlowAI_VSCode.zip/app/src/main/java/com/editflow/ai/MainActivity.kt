package com.editflow.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090A0F)
private val Panel = Color(0xFF12141B)
private val Accent = Color(0xFF7C5CFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EditFlowApp() }
    }
}

@Composable
fun EditFlowApp() {
    var screen by remember { mutableStateOf("home") }
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Panel,
            primary = Accent
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (screen == "home") HomeScreen { screen = "editor" }
            else EditorScreen { screen = "home" }
        }
    }
}

@Composable
fun HomeScreen(onNewProject: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("EditFlow AI", fontSize = 28.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                Text("Create. Edit. Flow.", color = Color.Gray)
            }
            IconButton(onClick = {}) { Icon(Icons.Default.Settings, "Settings") }
        }

        Button(
            onClick = onNewProject,
            modifier = Modifier.fillMaxWidth().height(58.dp),
            shape = RoundedCornerShape(18.dp)
        ) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(8.dp))
            Text("New Project", fontSize = 17.sp)
        }

        Text("Recent Projects", fontSize = 20.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)

        ProjectCard("My First Edit", "Just now")
        ProjectCard("Travel Video", "Yesterday")

        Spacer(Modifier.weight(1f))
        Text(
            "EditFlow AI • Local projects",
            modifier = Modifier.align(Alignment.CenterHorizontally),
            color = Color.Gray,
            fontSize = 12.sp
        )
    }
}

@Composable
fun ProjectCard(name: String, time: String) {
    Row(
        Modifier.fillMaxWidth()
            .background(Panel, RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(64.dp).background(Color(0xFF20232D), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Movie, null, tint = Accent) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(name, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            Text(time, color = Color.Gray, fontSize = 13.sp)
        }
        Icon(Icons.Default.MoreVert, null)
    }
}

@Composable
fun EditorScreen(onBack: () -> Unit) {
    var selectedTool by remember { mutableStateOf("Edit") }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("Untitled Project", Modifier.weight(1f), fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
            IconButton(onClick = {}) { Icon(Icons.Default.Undo, "Undo") }
            IconButton(onClick = {}) { Icon(Icons.Default.Redo, "Redo") }
            TextButton(onClick = {}) { Text("Export") }
        }

        Box(
            Modifier.fillMaxWidth().weight(1f).padding(12.dp)
                .background(Color.Black, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.PlayCircle, null, tint = Color.White, modifier = Modifier.size(64.dp))
                Spacer(Modifier.height(8.dp))
                Text("Preview", color = Color.Gray)
            }
        }

        Text(
            "00:00.00 / 00:00.00",
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            color = Color.Gray
        )

        Timeline()

        Row(
            Modifier.fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "Edit", "Split", "Trim", "Speed", "Volume", "Crop",
                "Rotate", "Adjust", "Filter", "Effect", "Transition",
                "Text", "Sticker", "Overlay", "Audio", "Voiceover", "Captions"
            ).forEach { tool ->
                FilterChip(
                    selected = selectedTool == tool,
                    onClick = { selectedTool = tool },
                    label = { Text(tool) }
                )
            }
        }
    }
}

@Composable
fun Timeline() {
    Column(
        Modifier.fillMaxWidth()
            .background(Panel)
            .padding(10.dp)
    ) {
        Text("Timeline", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            repeat(8) {
                Box(
                    Modifier.width(105.dp).height(52.dp)
                        .background(
                            if (it == 0) Accent.copy(alpha = .35f) else Color(0xFF242733),
                            RoundedCornerShape(7.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) { Text("Clip ${it + 1}", fontSize = 12.sp) }
            }
        }
        Spacer(Modifier.height(7.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            repeat(8) {
                Box(
                    Modifier.width(105.dp).height(30.dp)
                        .background(Color(0xFF1B1E27), RoundedCornerShape(5.dp))
                )
            }
        }
    }
}
